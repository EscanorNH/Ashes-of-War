<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
<tileset firstgid="298" name="decoration" columns="7" tilecount="35" tileheight="20" tilewidth="20">
  <image source="bitmaps/decoration.png" width="140" height="100" />
</tileset>