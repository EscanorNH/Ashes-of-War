<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Water" tilewidth="20" tileheight="20" tilecount="1" columns="1">
 <image source="bitmaps/water.png" trans="008a76" width="20" height="20"/>
 <tile id="0">
  <properties>
   <property name="water" value=""/>
  </properties>
 </tile>
</tileset>
